var hierarchy =
[
    [ "detail::Atomic_Queue< T >", "classdetail_1_1_atomic___queue.html", null ],
    [ "detail::Atomic_Queue< std::function< void(int id)> *>", "classdetail_1_1_atomic___queue.html", null ],
    [ "parser::output", "structparser_1_1output.html", null ],
    [ "detail::RAII_acquireFile", "classdetail_1_1_r_a_i_i__acquire_file.html", null ],
    [ "detail::RAII_lock", "classdetail_1_1_r_a_i_i__lock.html", null ],
    [ "SearchStrategy", "class_search_strategy.html", [
      [ "BoyerMooreSearch", "class_boyer_moore_search.html", null ],
      [ "regex_search", "classregex__search.html", null ]
    ] ],
    [ "thread_manager::ThreadPool", "classthread__manager_1_1_thread_pool.html", null ]
];