var namespaces =
[
    [ "call", "namespacecall.html", null ],
    [ "create-test", "namespacecreate-test.html", null ],
    [ "detail", "namespacedetail.html", null ],
    [ "parser", "namespaceparser.html", null ],
    [ "run-test", "namespacerun-test.html", null ],
    [ "thread_manager", "namespacethread__manager.html", null ]
];