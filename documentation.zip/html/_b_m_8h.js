var _b_m_8h =
[
    [ "BoyerMooreSearch", "class_boyer_moore_search.html", "class_boyer_moore_search" ],
    [ "ALPHABET_SIZE", "_b_m_8h.html#a6572f1706059832f94025fa12c6c45ed", null ],
    [ "BM_H", "_b_m_8h.html#acaf9f88c1705460b81f3e061beb5a4d0", null ]
];