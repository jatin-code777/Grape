var class_search_strategy =
[
    [ "pre_process", "class_search_strategy.html#a3d148ab56844813bc942b62057c4b8ac", null ],
    [ "search", "class_search_strategy.html#ae24a2a79e67c69ebeeb2ef5036bae623", null ],
    [ "COLOR_CYAN", "class_search_strategy.html#aeaced3f05c6aa787438f1a68bf01973d", null ],
    [ "COLOR_PURPLE", "class_search_strategy.html#a59bda946182de2b0d691133ee1fc11b1", null ],
    [ "COLOR_RED", "class_search_strategy.html#aa5422176a4202831e19221328d9f5787", null ],
    [ "COLOR_RED_BOLD", "class_search_strategy.html#a12e4bf08ff8834231cb32bd66ff89cd7", null ],
    [ "COLOR_RESET", "class_search_strategy.html#adc206c8699722f67ced84b1966c6e830", null ]
];