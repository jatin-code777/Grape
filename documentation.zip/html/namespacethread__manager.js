var namespacethread__manager =
[
    [ "ThreadPool", "classthread__manager_1_1_thread_pool.html", "classthread__manager_1_1_thread_pool" ]
];