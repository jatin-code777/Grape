var annotated_dup =
[
    [ "detail", "namespacedetail.html", "namespacedetail" ],
    [ "parser", "namespaceparser.html", "namespaceparser" ],
    [ "thread_manager", "namespacethread__manager.html", "namespacethread__manager" ],
    [ "BoyerMooreSearch", "class_boyer_moore_search.html", "class_boyer_moore_search" ],
    [ "regex_search", "classregex__search.html", "classregex__search" ],
    [ "SearchStrategy", "class_search_strategy.html", "class_search_strategy" ]
];