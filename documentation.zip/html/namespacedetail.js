var namespacedetail =
[
    [ "Atomic_Queue", "classdetail_1_1_atomic___queue.html", "classdetail_1_1_atomic___queue" ],
    [ "RAII_acquireFile", "classdetail_1_1_r_a_i_i__acquire_file.html", "classdetail_1_1_r_a_i_i__acquire_file" ],
    [ "RAII_lock", "classdetail_1_1_r_a_i_i__lock.html", "classdetail_1_1_r_a_i_i__lock" ]
];