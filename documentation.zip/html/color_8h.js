var color_8h =
[
    [ "COLOR_CYAN", "color_8h.html#a82573859711fce56f1aa0a76b18a9b18", null ],
    [ "COLOR_PURPLE", "color_8h.html#a361bd41194ac13caf9169f3f689dc179", null ],
    [ "COLOR_RED", "color_8h.html#ad86358bf19927183dd7b4ae215a29731", null ],
    [ "COLOR_RED_BOLD", "color_8h.html#ac77124c50bbd1dcc785f7cc7ad042366", null ],
    [ "COLOR_RESET", "color_8h.html#a17f760256046df23dd0ab46602f04d02", null ]
];