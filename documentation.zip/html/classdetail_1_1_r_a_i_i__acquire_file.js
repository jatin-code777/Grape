var classdetail_1_1_r_a_i_i__acquire_file =
[
    [ "RAII_acquireFile", "classdetail_1_1_r_a_i_i__acquire_file.html#a020539a46813be595c3a47a26587d7be", null ],
    [ "~RAII_acquireFile", "classdetail_1_1_r_a_i_i__acquire_file.html#a4d530aef9d2569cfe05a7841f671455b", null ]
];