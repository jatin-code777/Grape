var searchData=
[
  ['decider',['decider',['../call_8h.html#a6c768b02f9948bc4ab524ab4c2b6872b',1,'decider(bool regex, SearchStrategy *&amp;searcher):&#160;call.cpp'],['../call_8cpp.html#a6c768b02f9948bc4ab524ab4c2b6872b',1,'decider(bool regex, SearchStrategy *&amp;searcher):&#160;call.cpp']]]
];
