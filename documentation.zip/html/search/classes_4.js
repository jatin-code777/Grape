var searchData=
[
  ['searchstrategy',['SearchStrategy',['../class_search_strategy.html',1,'']]]
];
