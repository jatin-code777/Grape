var searchData=
[
  ['atomic_5fqueue',['Atomic_Queue',['../classdetail_1_1_atomic___queue.html',1,'detail']]],
  ['atomic_5fqueue_3c_20std_3a_3afunction_3c_20void_28int_20id_29_3e_20_2a_3e',['Atomic_Queue&lt; std::function&lt; void(int id)&gt; *&gt;',['../classdetail_1_1_atomic___queue.html',1,'detail']]]
];
