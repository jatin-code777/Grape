var searchData=
[
  ['c_5fdialect',['C_DIALECT',['../_c_make_c_compiler_id_8c.html#a07f8e5783674099cd7f5110e22a78cdb',1,'CMakeCCompilerId.c']]],
  ['color_5fcyan',['COLOR_CYAN',['../color_8h.html#a82573859711fce56f1aa0a76b18a9b18',1,'color.h']]],
  ['color_5fpurple',['COLOR_PURPLE',['../color_8h.html#a361bd41194ac13caf9169f3f689dc179',1,'color.h']]],
  ['color_5fred',['COLOR_RED',['../color_8h.html#ad86358bf19927183dd7b4ae215a29731',1,'color.h']]],
  ['color_5fred_5fbold',['COLOR_RED_BOLD',['../color_8h.html#ac77124c50bbd1dcc785f7cc7ad042366',1,'color.h']]],
  ['color_5freset',['COLOR_RESET',['../color_8h.html#a17f760256046df23dd0ab46602f04d02',1,'color.h']]],
  ['compiler_5fid',['COMPILER_ID',['../_c_make_c_compiler_id_8c.html#a81dee0709ded976b2e0319239f72d174',1,'COMPILER_ID():&#160;CMakeCCompilerId.c'],['../_c_make_c_x_x_compiler_id_8cpp.html#a81dee0709ded976b2e0319239f72d174',1,'COMPILER_ID():&#160;CMakeCXXCompilerId.cpp']]],
  ['cxx_5fstd',['CXX_STD',['../_c_make_c_x_x_compiler_id_8cpp.html#a34cc889e576a1ae6c84ae9e0a851ba21',1,'CMakeCXXCompilerId.cpp']]]
];
