var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstv~",
  1: "aborst",
  2: "cdprt",
  3: "abcfmrst",
  4: "cdegimnoprst~",
  5: "cefgilnprstv",
  6: "abcdhpst",
  7: "g"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Macros",
  7: "Pages"
};

