var searchData=
[
  ['c_5fflag',['c_flag',['../structparser_1_1output.html#a5388de05059ddc53a1547e20f945c43a',1,'parser::output']]],
  ['color_5fcyan',['COLOR_CYAN',['../class_search_strategy.html#aeaced3f05c6aa787438f1a68bf01973d',1,'SearchStrategy']]],
  ['color_5fpurple',['COLOR_PURPLE',['../class_search_strategy.html#a59bda946182de2b0d691133ee1fc11b1',1,'SearchStrategy']]],
  ['color_5fred',['COLOR_RED',['../class_search_strategy.html#aa5422176a4202831e19221328d9f5787',1,'SearchStrategy']]],
  ['color_5fred_5fbold',['COLOR_RED_BOLD',['../class_search_strategy.html#a12e4bf08ff8834231cb32bd66ff89cd7',1,'SearchStrategy']]],
  ['color_5freset',['COLOR_RESET',['../class_search_strategy.html#adc206c8699722f67ced84b1966c6e830',1,'SearchStrategy']]]
];
