var searchData=
[
  ['detail',['detail',['../namespacedetail.html',1,'']]]
];
